import g4f

stop = False

def get_response(prompt):
    response = g4f.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{'role': 'user', 'content': prompt}],
        stream=True,
        temperature=0.7, 
        language='ru'
    )
    return response

print("Type 'stop' to exit")
while stop:
    prompt = input("user:~# ") 
    if prompt == "stop":
        stop = True
    else:
        print(get_response(prompt)